﻿namespace _00010443
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.Label clientName_10443Label;
            System.Windows.Forms.Label clientAddress_10443Label;
            System.Windows.Forms.Label clientDOB_10443Label;
            System.Windows.Forms.Label clientBalance_10443Label;
            System.Windows.Forms.Label clientCategory_10443Label;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label label10;
            this.bankDataSet = new _00010443.BankDataSet();
            this.tb_ClientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_ClientTableAdapter = new _00010443.BankDataSetTableAdapters.tb_ClientTableAdapter();
            this.tableAdapterManager = new _00010443.BankDataSetTableAdapters.TableAdapterManager();
            this.tb_ClientBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.tb_ClientBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.clientName_10443TextBox = new System.Windows.Forms.TextBox();
            this.clientAddress_10443TextBox = new System.Windows.Forms.TextBox();
            this.clientDOB_10443DateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tbClientCategoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tb_ClientCategoryTableAdapter = new _00010443.BankDataSetTableAdapters.tb_ClientCategoryTableAdapter();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dateTimePickerNewClient = new System.Windows.Forms.DateTimePicker();
            this.tbxNewClientAddress = new System.Windows.Forms.TextBox();
            this.tbxNewClientName = new System.Windows.Forms.TextBox();
            this.combxNewClientCategory = new System.Windows.Forms.ComboBox();
            this.nudNewClientBalance = new System.Windows.Forms.NumericUpDown();
            this.btnAdd = new System.Windows.Forms.Button();
            this.tbClientCategoryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            clientName_10443Label = new System.Windows.Forms.Label();
            clientAddress_10443Label = new System.Windows.Forms.Label();
            clientDOB_10443Label = new System.Windows.Forms.Label();
            clientBalance_10443Label = new System.Windows.Forms.Label();
            clientCategory_10443Label = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bankDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ClientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ClientBindingNavigator)).BeginInit();
            this.tb_ClientBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbClientCategoryBindingSource)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNewClientBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbClientCategoryBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // bankDataSet
            // 
            this.bankDataSet.DataSetName = "BankDataSet";
            this.bankDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_ClientBindingSource
            // 
            this.tb_ClientBindingSource.DataMember = "tb_Client";
            this.tb_ClientBindingSource.DataSource = this.bankDataSet;
            this.tb_ClientBindingSource.CurrentChanged += new System.EventHandler(this.tb_ClientBindingSource_CurrentChanged);
            // 
            // tb_ClientTableAdapter
            // 
            this.tb_ClientTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.tb_ClientCategoryTableAdapter = this.tb_ClientCategoryTableAdapter;
            this.tableAdapterManager.tb_ClientTableAdapter = this.tb_ClientTableAdapter;
            this.tableAdapterManager.UpdateOrder = _00010443.BankDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tb_ClientBindingNavigator
            // 
            this.tb_ClientBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.tb_ClientBindingNavigator.BindingSource = this.tb_ClientBindingSource;
            this.tb_ClientBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.tb_ClientBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.tb_ClientBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tb_ClientBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tb_ClientBindingNavigatorSaveItem});
            this.tb_ClientBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.tb_ClientBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.tb_ClientBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.tb_ClientBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.tb_ClientBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.tb_ClientBindingNavigator.Name = "tb_ClientBindingNavigator";
            this.tb_ClientBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.tb_ClientBindingNavigator.Size = new System.Drawing.Size(1058, 31);
            this.tb_ClientBindingNavigator.TabIndex = 0;
            this.tb_ClientBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // tb_ClientBindingNavigatorSaveItem
            // 
            this.tb_ClientBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tb_ClientBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tb_ClientBindingNavigatorSaveItem.Image")));
            this.tb_ClientBindingNavigatorSaveItem.Name = "tb_ClientBindingNavigatorSaveItem";
            this.tb_ClientBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.tb_ClientBindingNavigatorSaveItem.Text = "Save Data";
            this.tb_ClientBindingNavigatorSaveItem.Click += new System.EventHandler(this.tb_ClientBindingNavigatorSaveItem_Click);
            // 
            // listBox1
            // 
            this.listBox1.DataSource = this.tb_ClientBindingSource;
            this.listBox1.DisplayMember = "ClientName_10443";
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Location = new System.Drawing.Point(22, 106);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(200, 148);
            this.listBox1.TabIndex = 1;
            // 
            // clientName_10443Label
            // 
            clientName_10443Label.AutoSize = true;
            clientName_10443Label.Location = new System.Drawing.Point(249, 116);
            clientName_10443Label.Name = "clientName_10443Label";
            clientName_10443Label.Size = new System.Drawing.Size(132, 17);
            clientName_10443Label.TabIndex = 4;
            clientName_10443Label.Text = "Client Name 10443:";
            // 
            // clientName_10443TextBox
            // 
            this.clientName_10443TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_ClientBindingSource, "ClientName_10443", true));
            this.clientName_10443TextBox.Location = new System.Drawing.Point(407, 113);
            this.clientName_10443TextBox.Name = "clientName_10443TextBox";
            this.clientName_10443TextBox.Size = new System.Drawing.Size(200, 22);
            this.clientName_10443TextBox.TabIndex = 5;
            // 
            // clientAddress_10443Label
            // 
            clientAddress_10443Label.AutoSize = true;
            clientAddress_10443Label.Location = new System.Drawing.Point(249, 144);
            clientAddress_10443Label.Name = "clientAddress_10443Label";
            clientAddress_10443Label.Size = new System.Drawing.Size(147, 17);
            clientAddress_10443Label.TabIndex = 6;
            clientAddress_10443Label.Text = "Client Address 10443:";
            // 
            // clientAddress_10443TextBox
            // 
            this.clientAddress_10443TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tb_ClientBindingSource, "ClientAddress_10443", true));
            this.clientAddress_10443TextBox.Location = new System.Drawing.Point(407, 141);
            this.clientAddress_10443TextBox.Name = "clientAddress_10443TextBox";
            this.clientAddress_10443TextBox.Size = new System.Drawing.Size(200, 22);
            this.clientAddress_10443TextBox.TabIndex = 7;
            // 
            // clientDOB_10443Label
            // 
            clientDOB_10443Label.AutoSize = true;
            clientDOB_10443Label.Location = new System.Drawing.Point(249, 173);
            clientDOB_10443Label.Name = "clientDOB_10443Label";
            clientDOB_10443Label.Size = new System.Drawing.Size(125, 17);
            clientDOB_10443Label.TabIndex = 8;
            clientDOB_10443Label.Text = "Client DOB 10443:";
            // 
            // clientDOB_10443DateTimePicker
            // 
            this.clientDOB_10443DateTimePicker.CustomFormat = "dd/MM/yyyy";
            this.clientDOB_10443DateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tb_ClientBindingSource, "ClientDOB_10443", true));
            this.clientDOB_10443DateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.clientDOB_10443DateTimePicker.Location = new System.Drawing.Point(407, 169);
            this.clientDOB_10443DateTimePicker.Name = "clientDOB_10443DateTimePicker";
            this.clientDOB_10443DateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.clientDOB_10443DateTimePicker.TabIndex = 9;
            // 
            // clientBalance_10443Label
            // 
            clientBalance_10443Label.AutoSize = true;
            clientBalance_10443Label.Location = new System.Drawing.Point(249, 200);
            clientBalance_10443Label.Name = "clientBalance_10443Label";
            clientBalance_10443Label.Size = new System.Drawing.Size(146, 17);
            clientBalance_10443Label.TabIndex = 10;
            clientBalance_10443Label.Text = "Client Balance 10443:";
            // 
            // clientCategory_10443Label
            // 
            clientCategory_10443Label.AutoSize = true;
            clientCategory_10443Label.Location = new System.Drawing.Point(249, 228);
            clientCategory_10443Label.Name = "clientCategory_10443Label";
            clientCategory_10443Label.Size = new System.Drawing.Size(152, 17);
            clientCategory_10443Label.TabIndex = 12;
            clientCategory_10443Label.Text = "Client Category 10443:";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.tb_ClientBindingSource, "ClientBalance_10443", true));
            this.numericUpDown1.Location = new System.Drawing.Point(407, 197);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(200, 22);
            this.numericUpDown1.TabIndex = 14;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tb_ClientBindingSource, "ClientCategory_10443", true));
            this.comboBox1.DataSource = this.tbClientCategoryBindingSource;
            this.comboBox1.DisplayMember = "ClientCategoryName_10443";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(407, 228);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 24);
            this.comboBox1.TabIndex = 15;
            this.comboBox1.ValueMember = "ID_10443";
            // 
            // tbClientCategoryBindingSource
            // 
            this.tbClientCategoryBindingSource.DataMember = "tb_ClientCategory";
            this.tbClientCategoryBindingSource.DataSource = this.bankDataSet;
            // 
            // tb_ClientCategoryTableAdapter
            // 
            this.tb_ClientCategoryTableAdapter.ClearBeforeFill = true;
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(22, 278);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(46, 35);
            this.btnFirst.TabIndex = 16;
            this.btnFirst.Text = "<<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(74, 278);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(46, 35);
            this.btnPrevious.TabIndex = 16;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(126, 278);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(46, 35);
            this.btnNext.TabIndex = 16;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(178, 278);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(46, 35);
            this.btnLast.TabIndex = 16;
            this.btnLast.Text = ">>";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(532, 278);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 35);
            this.btnSave.TabIndex = 17;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(532, 319);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 32);
            this.btnDelete.TabIndex = 18;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(label6);
            this.groupBox2.Controls.Add(label7);
            this.groupBox2.Controls.Add(label8);
            this.groupBox2.Controls.Add(this.dateTimePickerNewClient);
            this.groupBox2.Controls.Add(label9);
            this.groupBox2.Controls.Add(this.tbxNewClientAddress);
            this.groupBox2.Controls.Add(this.tbxNewClientName);
            this.groupBox2.Controls.Add(this.combxNewClientCategory);
            this.groupBox2.Controls.Add(label10);
            this.groupBox2.Controls.Add(this.nudNewClientBalance);
            this.groupBox2.Location = new System.Drawing.Point(637, 91);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(378, 198);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "New Client";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(6, 55);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(147, 17);
            label6.TabIndex = 6;
            label6.Text = "Client Address 10443:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(6, 139);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(152, 17);
            label7.TabIndex = 12;
            label7.Text = "Client Category 10443:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(6, 111);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(146, 17);
            label8.TabIndex = 10;
            label8.Text = "Client Balance 10443:";
            // 
            // dateTimePickerNewClient
            // 
            this.dateTimePickerNewClient.CustomFormat = "dd/MM/yyyy";
            this.dateTimePickerNewClient.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerNewClient.Location = new System.Drawing.Point(164, 80);
            this.dateTimePickerNewClient.Name = "dateTimePickerNewClient";
            this.dateTimePickerNewClient.Size = new System.Drawing.Size(200, 22);
            this.dateTimePickerNewClient.TabIndex = 9;
            this.dateTimePickerNewClient.Validating += new System.ComponentModel.CancelEventHandler(this.dateTimePickerNewClient_Validating);
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(6, 84);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(125, 17);
            label9.TabIndex = 8;
            label9.Text = "Client DOB 10443:";
            // 
            // tbxNewClientAddress
            // 
            this.tbxNewClientAddress.Location = new System.Drawing.Point(164, 52);
            this.tbxNewClientAddress.Name = "tbxNewClientAddress";
            this.tbxNewClientAddress.Size = new System.Drawing.Size(200, 22);
            this.tbxNewClientAddress.TabIndex = 7;
            // 
            // tbxNewClientName
            // 
            this.tbxNewClientName.Location = new System.Drawing.Point(164, 24);
            this.tbxNewClientName.Name = "tbxNewClientName";
            this.tbxNewClientName.Size = new System.Drawing.Size(200, 22);
            this.tbxNewClientName.TabIndex = 5;
            // 
            // combxNewClientCategory
            // 
            this.combxNewClientCategory.DataSource = this.tbClientCategoryBindingSource1;
            this.combxNewClientCategory.DisplayMember = "ClientCategoryName_10443";
            this.combxNewClientCategory.FormattingEnabled = true;
            this.combxNewClientCategory.Location = new System.Drawing.Point(164, 139);
            this.combxNewClientCategory.Name = "combxNewClientCategory";
            this.combxNewClientCategory.Size = new System.Drawing.Size(200, 24);
            this.combxNewClientCategory.TabIndex = 15;
            this.combxNewClientCategory.ValueMember = "ID_10443";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(6, 27);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(132, 17);
            label10.TabIndex = 4;
            label10.Text = "Client Name 10443:";
            // 
            // nudNewClientBalance
            // 
            this.nudNewClientBalance.Location = new System.Drawing.Point(164, 108);
            this.nudNewClientBalance.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.nudNewClientBalance.Name = "nudNewClientBalance";
            this.nudNewClientBalance.Size = new System.Drawing.Size(200, 22);
            this.nudNewClientBalance.TabIndex = 14;
            this.nudNewClientBalance.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(870, 306);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 31);
            this.btnAdd.TabIndex = 20;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // tbClientCategoryBindingSource1
            // 
            this.tbClientCategoryBindingSource1.DataMember = "tb_ClientCategory";
            this.tbClientCategoryBindingSource1.DataSource = this.bankDataSet;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1058, 384);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(clientName_10443Label);
            this.Controls.Add(this.clientName_10443TextBox);
            this.Controls.Add(clientAddress_10443Label);
            this.Controls.Add(this.clientAddress_10443TextBox);
            this.Controls.Add(clientDOB_10443Label);
            this.Controls.Add(this.clientDOB_10443DateTimePicker);
            this.Controls.Add(clientBalance_10443Label);
            this.Controls.Add(clientCategory_10443Label);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.tb_ClientBindingNavigator);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bankDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ClientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tb_ClientBindingNavigator)).EndInit();
            this.tb_ClientBindingNavigator.ResumeLayout(false);
            this.tb_ClientBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbClientCategoryBindingSource)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNewClientBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbClientCategoryBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private BankDataSet bankDataSet;
        private System.Windows.Forms.BindingSource tb_ClientBindingSource;
        private BankDataSetTableAdapters.tb_ClientTableAdapter tb_ClientTableAdapter;
        private BankDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator tb_ClientBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton tb_ClientBindingNavigatorSaveItem;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox clientName_10443TextBox;
        private System.Windows.Forms.TextBox clientAddress_10443TextBox;
        private System.Windows.Forms.DateTimePicker clientDOB_10443DateTimePicker;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private BankDataSetTableAdapters.tb_ClientCategoryTableAdapter tb_ClientCategoryTableAdapter;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.BindingSource tbClientCategoryBindingSource;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dateTimePickerNewClient;
        private System.Windows.Forms.TextBox tbxNewClientAddress;
        private System.Windows.Forms.TextBox tbxNewClientName;
        private System.Windows.Forms.ComboBox combxNewClientCategory;
        private System.Windows.Forms.NumericUpDown nudNewClientBalance;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.BindingSource tbClientCategoryBindingSource1;
    }
}

