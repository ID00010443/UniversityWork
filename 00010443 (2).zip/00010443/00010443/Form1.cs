﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _00010443
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tb_ClientBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            SaveData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'bankDataSet.tb_ClientCategory' table. You can move, or remove it, as needed.
            this.tb_ClientCategoryTableAdapter.Fill(this.bankDataSet.tb_ClientCategory);
            // TODO: This line of code loads data into the 'bankDataSet.tb_Client' table. You can move, or remove it, as needed.
            this.tb_ClientTableAdapter.Fill(this.bankDataSet.tb_Client);

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            tb_ClientBindingSource.MoveFirst();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            tb_ClientBindingSource.MovePrevious();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tb_ClientBindingSource.MoveNext();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tb_ClientBindingSource.MoveLast();
        }
        private void EnablingDisablingButtons()
        {
            if (tb_ClientBindingSource.Position == 0)
            {
                btnFirst.Enabled = false;
                btnPrevious.Enabled = false;
            }
            else
            {
                btnFirst.Enabled = true;
                btnPrevious.Enabled = true;
            }
            if (tb_ClientBindingSource.Position == tb_ClientBindingSource.Count - 1)
            {
                btnNext.Enabled = false;
                btnLast.Enabled = false;
            }
            else
            {
                btnNext.Enabled = true;
                btnLast.Enabled = true;
            }
        }

        private void tb_ClientBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            EnablingDisablingButtons();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveData();
        }
        private void SaveData()
        {
            if (this.Validate())
            {
                try
                {
                    this.tb_ClientBindingSource.EndEdit();
                    this.tableAdapterManager.UpdateAll(this.bankDataSet);
                    MessageBox.Show("Saved");
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
            }
            else
            {
                MessageBox.Show("there are errors");
            }

        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.Validate())
            {
                this.tb_ClientBindingSource.EndEdit();
                if (bankDataSet.HasChanges())
                {
                    if (MessageBox.Show("Do you want to save changes?", "Exit", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        SaveData();
                }
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (tb_ClientBindingSource.Count == 0)
            {
                MessageBox.Show("Nothing to show");
            }
            else
            {
                var userResponse = MessageBox.Show("Are you sure?", "Delete", MessageBoxButtons.YesNo);
                if (userResponse == DialogResult.Yes)
                    tb_ClientBindingSource.RemoveCurrent();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var clientSelected = ((DataRowView)combxNewClientCategory.SelectedItem).Row;
            bankDataSet.tb_Client.Addtb_ClientRow(
                tbxNewClientName.Text,
                tbxNewClientAddress.Text,
                dateTimePickerNewClient.Value,
                (int)nudNewClientBalance.Value,
                (BankDataSet.tb_ClientCategoryRow)clientSelected);

            tbxNewClientName.Text = "";
            tbxNewClientAddress.Text = "";
            MessageBox.Show("Saved");
        }

        private void dateTimePickerNewClient_Validating(object sender, CancelEventArgs e)
        {
            if (dateTimePickerNewClient.Value.AddYears(18) > DateTime.Now)
            {
                MessageBox.Show("You are young to be a client");
                e.Cancel = true;
            }
        }
    }
}
