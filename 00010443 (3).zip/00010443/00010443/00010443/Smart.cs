﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _00010443
{
    class Smart 
    {

    }
}
