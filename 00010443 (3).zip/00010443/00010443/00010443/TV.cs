﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _00010443
{
    public class TV
    {
        private int Id { get; }
        private string Model { get; }
        private float Price { get; }
        private string Screen { get; }
        private int Size { get; }
        private string Resolution {get;}

        public TV(int id, string model, float price, string screen, int size, string resolution)

        {
            this.Id = id;
            this.Model = model;
            this.Price = price;
            this.Screen = screen;
            this.Size = size;
            this.Resolution = resolution;

        }

        public string GetByModel()

        {
            return this.Model;
        }
       

        public override string ToString()
        {
            return "{Brand} | {Price.ToString()} | {Screen} | {Resolution}";
        }
    }
}
