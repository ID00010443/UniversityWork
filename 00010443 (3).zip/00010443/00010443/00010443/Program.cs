﻿using System;

namespace _00010443
{
    class Program
    {
       private static void Main()
        {
            Console.WriteLine("TV selling");

            









        }
    }
}
