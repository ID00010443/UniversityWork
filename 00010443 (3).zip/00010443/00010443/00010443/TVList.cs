﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace _00010443
{
    public class TVList
    {
        private static List<TV> TV = new List<TV>();

        public void AddTV(int id, string model, float price, string screen, int size, string resolution)
        {
            TV.Add(new TV(id, model, price, screen, size, resolution));
            Console.WriteLine("Adding the TV: " + model);
        }

        public List<TV> GetAllTVs()
        {
            return TV;
        }
        public List<TV> GetSmartTV()
        {
            List<TV>SmartTV = new List<TV>();
            foreach (TV TV in TV)
            {
                if (TV.GetByModel() == "Smart")
                {
                    SmartTV.Add(TV);
                } }
            return SmartTV;}

        public List<TV> GetRegularTV()
        {
            List<TV> RegularTV = new List<TV>();
            foreach (TV TV in TV)
            {
                if (TV.GetByModel() == "Regular")
                {
                    RegularTV.Add(TV);
                }
            }
            return RegularTV;
        }

        public List<TV> GetTVByModel(string model)
        {
            List<TV> TVByModel = new List<TV>();
            foreach (TV TV in TV)
            {
                if (TV.GetByModel() == model)
                {
                    TVByModel.Add(TV);
                }
            }
            return TVByModel;
        }

        public List<TV> SearchCarsByModel(string model)
        {
            List<TV> TVByModel = new List<TV>();
            foreach (TV TV in TV)
            {
                if (TV.GetByModel().Contains(model))
                {
                    TVByModel.Add(TV);
                }
            }
            return TVByModel;
        }




    }
}
        