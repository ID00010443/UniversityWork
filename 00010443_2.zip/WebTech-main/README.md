# Description

A log in log out page for a food company. The main functionality of the page is to make sure that the guest logs in and outs and sees the description of the file with corresponding photos. Nothing complicated was used to create this file- most importantly, there was no cheating at all- all the knowledge acquired during the lessons was implemented by heart, without peaking.

# Instructions.

First step - install all dependancies

```bash
npm install
```

Second step - run the project locally

```bash
node index
```

Third step - download the file from GitHub repo
[url] https://github.com/00010443/WebTech.git

Fourth step - visit the website on Glitch
[https://shard-pond-beryl.glitch.me/]

# Dependencies

The app is dependent on :
ExpressJS
NodeJS
Pug
