﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00010443
{
    class ScienceFiction:Books
    {
        public ScienceFictiobooks ScienceFictiobooks { get; set; }
    }

    public enum ScienceFictiobooks
    {
        rating,
        price,
        trends,
        viewes
    }

}
