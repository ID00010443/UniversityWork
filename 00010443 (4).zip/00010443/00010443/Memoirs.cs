﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00010443
{
    class Memoirs:Books
    {
        public Memoirbooks Memoirbooks { get; set; }
    }

    public enum Memoirbooks
    {
        rating,
        price,
        trends,
        viewes
    }
}
