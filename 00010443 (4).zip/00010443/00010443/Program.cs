﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00010443
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(@"
Welcome to Books Platform");
            OnlineShop st = OnlineShop.GetOnlineShop();
            st.Testing();

            repeatAction(st);
        }


        static void repeatAction(OnlineShop st)
        {
            Console.Write(@"
Select one of these actions
[1] Search a book
[2] Display all books
type number: ");
            string step1 = Console.ReadLine();

            if (step1 == "1")
            {
                searchBooks(st);
            }
            else if (step1 == "2")
            {
                displayBooksTable(st.Books);
            }
            else
            {
                Console.WriteLine("\nWRONG INPUT");
            }
            Console.WriteLine("");
            repeatAction(st);
        }

        static void searchBooks(OnlineShop st)
        {
            string selection = getSelection();
            if (selection == "1")
            {
                Console.WriteLine("\nYou choosed genre of the book, Enter the name of the book");
                string name = Console.ReadLine().Trim();
                displayBooksTable(st.SearchBooksByName(name));
            }
            else if (selection == "2")
            {
                List<Books> result = st.SearchBooksByLitrature(chooseLitrature());
                displayBooksTable(result);
            }
        }



    }
}
