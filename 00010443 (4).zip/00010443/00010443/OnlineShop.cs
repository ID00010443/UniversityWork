﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00010443
class OnlineShop
{
    public List<Books> Books { get; set; }
    public List<Memoirs> GetMemoirs()
    {
        List<Memoirs> Memoirbooks = new List<Memoirs>();
        foreach (Books books in OnlineShoping.Books)
        {
            if (books.Genre == Genre.Memoirs)
            {
                Memoirbooks.Add((Memoirs)books);
            }
        }
        return Memoirbooks;
    }

    private OnlineShop()
    {
        Books = new List<Books>();
    }

    private static OnlineShop OnlineShoping;

    public static OnlineShop GetOnlineShop()
    {
        if (OnlineShoping == null)
        {
            OnlineShoping = new OnlineShop();
        }
        return OnlineShoping;
    }

    public List<Books> SearchBooksByName(string booksName)
    {
        List<Books> searchResults = new List<Books>();
        foreach (Books books in OnlineShoping.Books)
        {
            if (books.Name.ToUpper().Contains(booksName.ToUpper()))
            {
                searchResults.Add(books);
            }
        }
        return searchResults;
    }

    public List<Books> SearchBooksByLitrature(Litraturebooks Litraturebooks)
    {
        List<Books> searchResults = new List<Books>();
        foreach (Litrature books in OnlineShoping.GetLitrature())
        {
            if (Books.Litrature == litrature)
            {
                searchResults.Add(books);
            }
        }
        return searchResults;
    }

    public void Testing()
    {
        OnlineShop st = GetOnlineShop();
        Books book1 = new Litrature()
        {
            Name = "Sorry Not Sorry",
            Price = 22,
            PublishedYear = 2010,
            Ratings = Ratings.Bad,
            Genre = Genre.Litrature
        };

        st.Books.Add(book1);

        OnlineShop st = GetOnlineShop();
        Books book2 = new Litrature()
        {
            Name = "Meet Cute",
            Price = 35,
            PublishedYear = 2012,
            Ratings = Ratings.Good,
            Genre = Genre.Litrature
        };

        st.Books.Add(book1);
        st.Books.Add(book2);
    }
}
}