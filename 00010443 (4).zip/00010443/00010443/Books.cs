﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00010443
{
    class Books
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Name { get; set; }
        public int Price { get; set; }
        public int PublishedYear { get; set; }
        public int Ratings { get; set; }
        public Genre Genre { get; set; }

        public int YearsOfUsing()
        {
            return DateTime.Now.Year - PublishedYear;
        }
    }
}

public enum Ratings
{
    Excelent,
    Good,
    Bad,
    Terrible
}

public enum Genre
{
    Memoirs,
    Litrature,
    Mystery,
    ScienceFiction
}
