﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00010443
{
    class Mystery:Books
    {
        public Mysterybooks Mysterybooks { get; set; }
    }

    public enum Mysterybooks
    {
        rating,
        price,
        trends,
        viewes
    }
}
