-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 11 2022 г., 22:42
-- Версия сервера: 5.7.33
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `security`
--

-- --------------------------------------------------------

--
-- Структура таблицы `psec_bad-words`
--

CREATE TABLE `psec_bad-words` (
  `id` int(11) NOT NULL,
  `word` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `psec_bans`
--

CREATE TABLE `psec_bans` (
  `id` int(11) NOT NULL,
  `ip` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoban` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `psec_bans-country`
--

CREATE TABLE `psec_bans-country` (
  `id` int(11) NOT NULL,
  `country` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `psec_bans-other`
--

CREATE TABLE `psec_bans-other` (
  `id` int(11) NOT NULL,
  `type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `psec_bans-ranges`
--

CREATE TABLE `psec_bans-ranges` (
  `id` int(11) NOT NULL,
  `ip_range` char(19) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `psec_dnsbl-databases`
--

CREATE TABLE `psec_dnsbl-databases` (
  `id` int(11) NOT NULL,
  `database` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `psec_dnsbl-databases`
--

INSERT INTO `psec_dnsbl-databases` (`id`, `database`) VALUES
(1, 'sbl.spamhaus.org'),
(2, 'xbl.spamhaus.org');

-- --------------------------------------------------------

--
-- Структура таблицы `psec_file-whitelist`
--

CREATE TABLE `psec_file-whitelist` (
  `id` int(11) NOT NULL,
  `path` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `psec_ip-whitelist`
--

CREATE TABLE `psec_ip-whitelist` (
  `id` int(11) NOT NULL,
  `ip` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `psec_ip-whitelist`
--

INSERT INTO `psec_ip-whitelist` (`id`, `ip`, `notes`) VALUES
(1, '5.252.201.75', 'test');

-- --------------------------------------------------------

--
-- Структура таблицы `psec_live-traffic`
--

CREATE TABLE `psec_live-traffic` (
  `id` int(11) NOT NULL,
  `ip` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `useragent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `browser` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `browser_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `os` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `os_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_code` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'XX',
  `request_uri` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bot` tinyint(1) NOT NULL DEFAULT '0',
  `date` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uniquev` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `psec_logins`
--

CREATE TABLE `psec_logins` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `successful` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `psec_logins`
--

INSERT INTO `psec_logins` (`id`, `username`, `ip`, `date`, `time`, `successful`) VALUES
(1, 'admin', '127.0.0.1', '11 April 2022', '21:53', 1),
(2, 'admin', '127.0.0.1', '11 April 2022', '22:24', 1),
(3, 'admin', '127.0.0.1', '11 April 2022', '22:40', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `psec_logs`
--

CREATE TABLE `psec_logs` (
  `id` int(11) NOT NULL,
  `ip` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` char(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `browser` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `browser_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `os` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `os_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `country_code` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'XX',
  `region` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `city` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `latitude` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `longitude` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `isp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `useragent` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `referer_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `psec_logs`
--

INSERT INTO `psec_logs` (`id`, `ip`, `date`, `time`, `page`, `query`, `type`, `browser`, `browser_code`, `os`, `os_code`, `country`, `country_code`, `region`, `city`, `latitude`, `longitude`, `isp`, `useragent`, `referer_url`) VALUES
(1, '127.0.0.1', '11 April 2022', '22:09', '/security-site/index.php', 'category=Gifts%27+OR+1=1--', 'SQLi', 'Google Chrome 100.0.4896.75', 'chrome', 'Windows 10 x64', 'win-6', 'Unknown', 'XX', 'Unknown', 'Unknown', '0', '0', 'Unknown', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36', '');

-- --------------------------------------------------------

--
-- Структура таблицы `psec_pages-layolt`
--

CREATE TABLE `psec_pages-layolt` (
  `id` int(11) NOT NULL,
  `page` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `psec_pages-layolt`
--

INSERT INTO `psec_pages-layolt` (`id`, `page`, `text`) VALUES
(1, 'Banned', 'You are banned and you cannot continue to the website'),
(2, 'Blocked', 'Malicious request was detected'),
(3, 'Proxy', 'Access to the website via Proxy, VPN, TOR is not allowed (Disable Browser Data Compression if you have it enabled)'),
(4, 'Spam', 'You are in the Blacklist of Spammers and you cannot continue to the website'),
(5, 'Banned_Country', 'Sorry, but your country is banned and you cannot continue to the website'),
(6, 'Blocked_Browser', 'Access to the website through your Browser is not allowed, please use another Internet Browser'),
(7, 'Blocked_OS', 'Access to the website through your Operating System is not allowed'),
(8, 'Blocked_ISP', 'Your Internet Service Provider is blacklisted and you cannot continue to the website'),
(9, 'Blocked_RFR', 'Your referrer url is blocked and you cannot continue to the website');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `psec_bad-words`
--
ALTER TABLE `psec_bad-words`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_bans`
--
ALTER TABLE `psec_bans`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_bans-country`
--
ALTER TABLE `psec_bans-country`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_bans-other`
--
ALTER TABLE `psec_bans-other`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_bans-ranges`
--
ALTER TABLE `psec_bans-ranges`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_dnsbl-databases`
--
ALTER TABLE `psec_dnsbl-databases`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_file-whitelist`
--
ALTER TABLE `psec_file-whitelist`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_ip-whitelist`
--
ALTER TABLE `psec_ip-whitelist`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_live-traffic`
--
ALTER TABLE `psec_live-traffic`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_logins`
--
ALTER TABLE `psec_logins`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_logs`
--
ALTER TABLE `psec_logs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `psec_pages-layolt`
--
ALTER TABLE `psec_pages-layolt`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `psec_bad-words`
--
ALTER TABLE `psec_bad-words`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `psec_bans`
--
ALTER TABLE `psec_bans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `psec_bans-country`
--
ALTER TABLE `psec_bans-country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `psec_bans-other`
--
ALTER TABLE `psec_bans-other`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `psec_bans-ranges`
--
ALTER TABLE `psec_bans-ranges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `psec_dnsbl-databases`
--
ALTER TABLE `psec_dnsbl-databases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `psec_file-whitelist`
--
ALTER TABLE `psec_file-whitelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `psec_ip-whitelist`
--
ALTER TABLE `psec_ip-whitelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `psec_live-traffic`
--
ALTER TABLE `psec_live-traffic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `psec_logins`
--
ALTER TABLE `psec_logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `psec_logs`
--
ALTER TABLE `psec_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `psec_pages-layolt`
--
ALTER TABLE `psec_pages-layolt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
