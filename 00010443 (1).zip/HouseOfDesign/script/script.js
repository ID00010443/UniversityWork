const togglebtn = document.querySelector('.burger');
/* selected class .burger */
var mnav = document.querySelector('.mobnav');
/* selected class .mnav */
let toggleOn = false;
togglebtn.addEventListener('click', () => {
    if (!toggleOn) {
        togglebtn.classList.add('open');
        /* give class open to .burger on click */
        mnav.classList.add('active');
        /* give class active to .mobnav on click */
        toggleOn = true;
    } else {
        togglebtn.classList.remove('open');
        /* remove class open from .burger on click */
        mnav.classList.remove('active');
        /* remove class active from .mobnav on click */
        toggleOn = false;
    }
});

function on() {
    document.getElementById("content-overlay").style.display = "block";
    /* give #content-overlay display: block */
}

function off() {
    document.getElementById("content-overlay").style.display = "none";
    /* give #content-overlay display: none */
}

function validate() {
    var regName = /^[a-zA-Z]+$/; /* pattern that can be used as an input */
    var name = document.getElementById('name_input').value; /* grabbing input of the user */
    if (!regName.test(name)) {
        alert('Please enter your full name (first & last name).'); /* if pattern is wrong or blank input, messagebox is shown */
        document.getElementById('name').focus();
        return false;
    } else {}
}